/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<math.h>
int main()
{
    int size,m,n,pgno,pagetable[3]={5,6,7},i,j,frameno;
    double m1;
    int ra=0,ofs;
    printf("Enter process size (in KB of max 12KB):");
    scanf("%d",&size);
    m1=size/4;
    n=ceil(m1);
    printf("Total No. of pages: %d",n);
    printf("\nEnter relative address (in hexadecimal notation eg.0XRA) \n");
    scanf("%d",&ra);
    pgno=ra/1000;
    ofs=ra%1000;
    printf("page no=%d\n",pgno);
    printf("page table");
    for(i=0;i<n;i++)
        printf("\n %d [%d]",i,pagetable[i]);
    frameno=pagetable[pgno];
    printf("\n Equivalent physical address : %d%d",frameno,ofs);
    return 0;
}
